﻿# =====================================================================
#  desktopchill · Setup Kit  (chạy trên máy khách qua Ultraview)
#  Windows PowerShell 5.1+  ·  Mở bằng file CHAY-SETUP.bat
#  Không gửi dữ liệu đi đâu. Chỉ đọc cấu hình máy, cài Rainmeter,
#  chép skin và áp layout trong thư mục người dùng.
# =====================================================================
$ErrorActionPreference = 'Stop'
try { [Console]::OutputEncoding = [Text.Encoding]::UTF8 } catch {}
$KIT        = Split-Path -Parent $MyInvocation.MyCommand.Path
$FILES      = Join-Path $KIT 'files'
$LAYOUTS    = Join-Path $KIT 'layouts'
$WORKSHOP   = 'https://steamcommunity.com/sharedfiles/filedetails/?id=3796644631'   # bộ sưu tập Workshop của shop
$WE_APPID   = '431960'                                                              # Wallpaper Engine trên Steam
$LAYOUT_PREFIX = 'desktopchill - '

# ---------------------------------------------------------------- tiện ích
function Title($t)  { Write-Host ''; Write-Host ('=== ' + $t + ' ===') -ForegroundColor Cyan }
function Ok($t)     { Write-Host ('  [OK] ' + $t) -ForegroundColor Green }
function Warn($t)   { Write-Host ('  [!]  ' + $t) -ForegroundColor Yellow }
function Info($t)   { Write-Host ('       ' + $t) }
function Pause-Enter { Write-Host ''; [void](Read-Host 'Nhấn Enter để quay lại menu') }

function Read-Ini([string]$path) {
  # Trả về [ordered]@{ 'Section' = [ordered]@{ key = value } } — giữ nguyên thứ tự
  $data = [ordered]@{}; $cur = $null
  if (-not (Test-Path $path)) { return $data }
  foreach ($line in (Get-Content -LiteralPath $path)) {
    $l = $line.Trim()
    if ($l -eq '' -or $l.StartsWith(';')) { continue }
    if ($l -match '^\[(.+)\]$') { $cur = $Matches[1]; if (-not $data.Contains($cur)) { $data[$cur] = [ordered]@{} }; continue }
    if ($cur -ne $null -and $l -match '^([^=]+?)\s*=\s*(.*)$') { $data[$cur][$Matches[1]] = $Matches[2] }
  }
  return $data
}
function Write-Ini($data, [string]$path) {
  $sb = New-Object Text.StringBuilder
  foreach ($sec in $data.Keys) {
    [void]$sb.AppendLine('[' + $sec + ']')
    foreach ($k in $data[$sec].Keys) { [void]$sb.AppendLine($k + '=' + $data[$sec][$k]) }
    [void]$sb.AppendLine('')
  }
  $dir = Split-Path -Parent $path
  if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
  [IO.File]::WriteAllText($path, $sb.ToString(), [Text.Encoding]::Unicode)   # Rainmeter dùng UTF-16 LE
}

function Get-Rainmeter {
  $exe = $null
  foreach ($k in 'HKLM:\SOFTWARE\Rainmeter','HKLM:\SOFTWARE\WOW6432Node\Rainmeter') {
    try { $p = (Get-ItemProperty -Path $k -ErrorAction Stop).'(default)'; if ($p -and (Test-Path (Join-Path $p 'Rainmeter.exe'))) { $exe = Join-Path $p 'Rainmeter.exe'; break } } catch {}
  }
  if (-not $exe) { foreach ($c in "$env:ProgramFiles\Rainmeter\Rainmeter.exe", "${env:ProgramFiles(x86)}\Rainmeter\Rainmeter.exe") { if ($c -and (Test-Path $c)) { $exe = $c; break } } }
  $ini = Join-Path $env:APPDATA 'Rainmeter\Rainmeter.ini'
  $skinPath = Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'Rainmeter\Skins'
  $cfg = Read-Ini $ini
  if ($cfg.Contains('Rainmeter') -and $cfg['Rainmeter'].Contains('SkinPath') -and $cfg['Rainmeter']['SkinPath']) { $skinPath = $cfg['Rainmeter']['SkinPath'].TrimEnd('\') }
  return [pscustomobject]@{ Exe = $exe; Ini = $ini; SkinPath = $skinPath; Layouts = (Join-Path $env:APPDATA 'Rainmeter\Layouts') }
}
function Send-Bang([string[]]$bang) {
  $rm = Get-Rainmeter
  if (-not $rm.Exe) { Warn 'Chưa có Rainmeter — chạy mục 2 trước.'; return $false }
  if (-not (Get-Process -Name Rainmeter -ErrorAction SilentlyContinue)) { Start-Process -FilePath $rm.Exe; Start-Sleep -Seconds 3 }
  & $rm.Exe @bang
  return $true
}
function Get-PhysicalScreen {
  # Độ phân giải thật (WMI) và % scale của Windows
  $vc = Get-CimInstance Win32_VideoController | Where-Object { $_.CurrentHorizontalResolution } | Select-Object -First 1
  $physW = 0; $physH = 0
  if ($vc) { $physW = [int]$vc.CurrentHorizontalResolution; $physH = [int]$vc.CurrentVerticalResolution }
  Add-Type -AssemblyName System.Windows.Forms
  $b = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds
  if (-not $physW) { $physW = $b.Width; $physH = $b.Height }
  $scale = 100; if ($b.Width -gt 0) { $scale = [int][math]::Round($physW / $b.Width * 100) }
  return [pscustomobject]@{ W = $physW; H = $physH; Scale = $scale; Count = [System.Windows.Forms.Screen]::AllScreens.Count }
}

# ---------------------------------------------------------------- 1. Kiểm tra máy
function Check-Machine {
  Title '1. KIỂM TRA MÁY'
  $os   = Get-CimInstance Win32_OperatingSystem
  $cpu  = (Get-CimInstance Win32_Processor | Select-Object -First 1).Name.Trim()
  $gpus = @(Get-CimInstance Win32_VideoController | ForEach-Object { $_.Name })
  $ram  = [math]::Round($os.TotalVisibleMemorySize / 1MB)
  $bat  = @(Get-CimInstance Win32_Battery -ErrorAction SilentlyContinue)
  $isLaptop = $bat.Count -gt 0
  $scr  = Get-PhysicalScreen
  $c    = Get-PSDrive -Name C -ErrorAction SilentlyContinue
  $freeGB = 0; if ($c) { $freeGB = [math]::Round($c.Free / 1GB) }
  $win  = $os.Caption -replace 'Microsoft ', ''
  $hasDedicated = [bool]($gpus | Where-Object { $_ -match 'NVIDIA|GeForce|RTX|GTX|Radeon RX|Arc A' })

  $kind = 'PC'; if ($isLaptop) { $kind = 'Laptop' }
  Info ('Loại máy : ' + $kind)
  Info ('Windows  : ' + $win + ' (build ' + $os.BuildNumber + ')')
  Info ('CPU      : ' + $cpu)
  Info ('GPU      : ' + ($gpus -join ' + '))
  Info ('RAM      : ' + $ram + ' GB')
  Info ('Màn hình : ' + $scr.W + 'x' + $scr.H + ' · scale ' + $scr.Scale + '% · ' + $scr.Count + ' màn hình')
  Info ('Ổ C trống: ' + $freeGB + ' GB')

  Write-Host ''; Write-Host '  Đề xuất cài đặt:' -ForegroundColor Cyan
  $weak = ($ram -lt 8) -or (-not $hasDedicated -and $cpu -match 'Celeron|Pentium|Athlon|i3-[2-7]')
  if ($weak) { Warn 'Máy yếu → Wallpaper Engine: FPS 25, chất lượng Thấp, ưu tiên mẫu video 1080p, tắt hiệu ứng nặng (bloom, MSAA).' }
  elseif (-not $hasDedicated) { Ok 'Card onboard → FPS 30, chất lượng Trung bình. Tránh mẫu scene quá nặng.' }
  else { Ok 'Có card rời → FPS 30–60, chất lượng Cao.' }
  if ($isLaptop) { Ok 'Laptop → bật "Tạm dừng khi dùng pin" (Settings > Performance).' }
  if ($scr.W -lt 1600) { Warn 'Màn hình nhỏ (<1600px) → giảm Scale skin còn ~0.8, chọn layout ít widget.' }
  if ($scr.W -ge 2560) { Warn 'Màn 2K/4K → tăng Scale skin ~1.3–2, kiểm tra chữ có quá nhỏ không.' }
  if ($scr.Scale -gt 100) { Info ('Windows đang phóng to ' + $scr.Scale + '% → skin Rainmeter tính theo pixel thật, kiểm tra lại kích cỡ.') }
  if ($scr.Count -gt 1) { Warn 'Nhiều màn hình → áp layout xong kiểm tra skin nằm đúng màn hình chính.' }
  if ($freeGB -lt 15) { Warn ('Ổ C chỉ còn ' + $freeGB + ' GB → cân nhắc để kho hình Workshop sang ổ khác.') }
  if ([int]$os.BuildNumber -lt 17763) { Warn 'Windows quá cũ → nên cập nhật trước khi cài.' }

  $summary = '{0} | {1} | {2}GB RAM | {3} | {4}x{5} @{6}% | {7} | C trống {8}GB' -f $kind, $cpu, $ram, ($gpus -join ' + '), $scr.W, $scr.H, $scr.Scale, $win, $freeGB
  try { Set-Clipboard -Value $summary; Write-Host ''; Ok 'Đã copy tóm tắt cấu hình → dán vào cột "Mẫu/cấu hình" trong Profit Tracker.' } catch { Info $summary }
}

# ---------------------------------------------------------------- 2. Cài Rainmeter
function Install-Rainmeter {
  Title '2. CÀI RAINMETER'
  $rm = Get-Rainmeter
  if ($rm.Exe) { Ok ('Đã có Rainmeter: ' + $rm.Exe); return }
  $setup = Get-ChildItem -Path $FILES -Filter 'Rainmeter*.exe' -ErrorAction SilentlyContinue | Select-Object -First 1
  if (-not $setup) { Warn ('Không thấy file cài Rainmeter trong ' + $FILES); return }
  Info ('Đang cài ' + $setup.Name + ' (chế độ im lặng, tự khởi động cùng Windows)...')
  Info 'Nếu Windows hỏi quyền (UAC) → chọn Yes. Ultraview chạy dạng portable có thể không thấy hộp thoại này: nhờ khách bấm Yes.'
  Start-Process -FilePath $setup.FullName -ArgumentList '/S','/AUTOSTARTUP=1' -Verb RunAs -Wait
  $rm = Get-Rainmeter
  if ($rm.Exe) { Ok 'Cài Rainmeter xong.'; Start-Process -FilePath $rm.Exe } else { Warn 'Chưa thấy Rainmeter sau khi cài — mở file cài bằng tay.' }
}

# ---------------------------------------------------------------- 3. Cài bộ skin
function Install-Skins {
  Title '3. CÀI BỘ SKIN CỦA SHOP'
  $rm = Get-Rainmeter
  $pkgs = @(Get-ChildItem -Path $FILES -Filter '*.rmskin' -ErrorAction SilentlyContinue)
  if ($pkgs.Count -eq 0) { Warn ('Không có file .rmskin trong ' + $FILES); return }
  foreach ($pkg in $pkgs) {
    Info ('Giải nén ' + $pkg.Name + ' ...')
    $tmp = Join-Path $env:TEMP ('dc_' + [guid]::NewGuid().ToString('N'))
    $zip = $tmp + '.zip'
    # .rmskin = file zip + 16 byte đuôi "RMSKIN" → cắt đuôi để Expand-Archive đọc chắc chắn
    $bytes = [IO.File]::ReadAllBytes($pkg.FullName)
    $len = $bytes.Length
    if ($len -gt 16 -and [Text.Encoding]::ASCII.GetString($bytes, $len - 7, 6) -eq 'RMSKIN') { $len = $len - 16 }
    $fs = [IO.File]::Create($zip); $fs.Write($bytes, 0, $len); $fs.Close()
    Expand-Archive -LiteralPath $zip -DestinationPath $tmp -Force
    $src = Join-Path $tmp 'Skins'
    if (Test-Path $src) {
      if (-not (Test-Path $rm.SkinPath)) { New-Item -ItemType Directory -Path $rm.SkinPath -Force | Out-Null }
      Get-ChildItem -LiteralPath $src -Directory | ForEach-Object {
        Copy-Item -LiteralPath $_.FullName -Destination $rm.SkinPath -Recurse -Force
        Ok ('Skin: ' + $_.Name)
      }
    }
    $lay = Join-Path $tmp 'Layouts'
    if (Test-Path $lay) { Copy-Item -Path (Join-Path $lay '*') -Destination $rm.Layouts -Recurse -Force; Ok 'Đã chép layout trong gói.' }
    Remove-Item -LiteralPath $zip -Force -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath $tmp -Recurse -Force -ErrorAction SilentlyContinue
  }
  if (Send-Bang @('!RefreshApp')) { Ok 'Rainmeter đã làm mới danh sách skin.' }
}

# ---------------------------------------------------------------- 4. Áp layout chuẩn
function Apply-Layout {
  Title '4. ÁP LAYOUT CHUẨN'
  $list = @(Get-ChildItem -Path $LAYOUTS -Filter '*.ini' -ErrorAction SilentlyContinue | Sort-Object Name)
  if ($list.Count -eq 0) { Warn 'Chưa có layout chuẩn nào. Trên máy của bạn: xếp skin đẹp rồi chạy mục 5 để lưu.'; return }
  for ($i = 0; $i -lt $list.Count; $i++) { Info ('[' + ($i + 1) + '] ' + $list[$i].BaseName) }
  $n = Read-Host 'Chọn số layout'
  $idx = 0; if (-not [int]::TryParse($n, [ref]$idx) -or $idx -lt 1 -or $idx -gt $list.Count) { Warn 'Số không hợp lệ.'; return }
  $pick = $list[$idx - 1]
  $rm = Get-Rainmeter
  $name = $LAYOUT_PREFIX + $pick.BaseName
  $data = Read-Ini $pick.FullName
  # kiểm tra skin cần dùng đã có trên máy chưa
  foreach ($sec in $data.Keys) {
    if ($sec -eq 'Rainmeter') { continue }
    if (-not (Test-Path (Join-Path $rm.SkinPath $sec))) { Warn ('Thiếu skin "' + $sec + '" — chạy mục 3 hoặc cài skin này trước.') }
  }
  Write-Ini $data (Join-Path (Join-Path $rm.Layouts $name) 'Rainmeter.ini')
  if (Send-Bang @('!LoadLayout', $name)) { Ok ('Đã áp layout "' + $pick.BaseName + '". Vị trí tính theo % màn hình — chỉ cần chỉnh nhẹ nếu màn hình khác tỉ lệ 16:9.') }
}

# ---------------------------------------------------------------- 5. Lưu layout hiện tại (dùng trên MÁY CỦA BẠN)
function Save-Layout {
  Title '5. LƯU LAYOUT HIỆN TẠI THÀNH LAYOUT CHUẨN'
  Info 'Dùng trên máy của bạn: xếp skin thật đẹp trước, rồi chạy mục này.'
  $rm = Get-Rainmeter
  $cfg = Read-Ini $rm.Ini
  if ($cfg.Count -eq 0) { Warn ('Không đọc được ' + $rm.Ini); return }
  $scr = Get-PhysicalScreen
  $keep = 'Active','WindowX','WindowY','AnchorX','AnchorY','AlwaysOnTop','ClickThrough','Draggable','SnapEdges','KeepOnScreen','AlphaValue','FadeDuration','HideOnMouseOver','LoadOrder','SavePosition','AutoSelectScreen'
  $out = [ordered]@{ 'Rainmeter' = [ordered]@{} }
  $count = 0
  foreach ($sec in $cfg.Keys) {
    if ($sec -eq 'Rainmeter' -or $sec -eq 'TrayMeasure') { continue }
    $s = $cfg[$sec]
    if (-not $s.Contains('Active') -or $s['Active'] -eq '0') { continue }
    $o = [ordered]@{}
    foreach ($k in $keep) { if ($s.Contains($k)) { $o[$k] = $s[$k] } }
    foreach ($axis in 'WindowX','WindowY') {
      if ($o.Contains($axis) -and $o[$axis] -match '^-?\d+$') {
        $total = $scr.W; if ($axis -eq 'WindowY') { $total = $scr.H }
        $o[$axis] = ([math]::Round([double]$o[$axis] / $total * 100, 2)).ToString([Globalization.CultureInfo]::InvariantCulture) + '%'
      }
    }
    $out[$sec] = $o; $count++
  }
  if ($count -eq 0) { Warn 'Không có skin nào đang bật.'; return }
  $name = Read-Host 'Đặt tên layout (vd: Equi Neon, Anime Clean)'
  if (-not $name) { $name = 'Layout ' + (Get-Date -Format 'yyyyMMdd-HHmm') }
  $name = ($name -replace '[\\/:*?"<>|]', '').Trim()
  if (-not (Test-Path $LAYOUTS)) { New-Item -ItemType Directory -Path $LAYOUTS -Force | Out-Null }
  $dest = Join-Path $LAYOUTS ($name + '.ini')
  Write-Ini $out $dest
  Ok ('Đã lưu ' + $count + ' skin → ' + $dest)
  Info ('Màn hình gốc: ' + $scr.W + 'x' + $scr.H + ' — vị trí đã đổi sang % để dùng cho màn hình khác.')
}

# ---------------------------------------------------------------- 7. Cá nhân hoá skin desktopchill
function Personalize-DcSkin {
  Title '7. CÁ NHÂN HOÁ SKIN DESKTOPCHILL (tên + kích cỡ)'
  $rm = Get-Rainmeter
  $vars = Join-Path $rm.SkinPath 'desktopchill\@Resources\Variables.inc'
  if (-not (Test-Path $vars)) { Warn 'Chưa có skin desktopchill — chạy mục 3 trước (cần file desktopchill_*.rmskin trong thư mục files).'; return }
  $scr = Get-PhysicalScreen
  $suggest = [math]::Round($scr.H / 1080, 2)
  $ten = Read-Host 'Tên hiện trong lời chào (Enter = giữ "bạn")'
  $sc  = Read-Host ('Scale (Enter = ' + $suggest.ToString([Globalization.CultureInfo]::InvariantCulture) + ' theo màn ' + $scr.W + 'x' + $scr.H + ')')
  if (-not $sc) { $sc = $suggest.ToString([Globalization.CultureInfo]::InvariantCulture) }
  $txt = [IO.File]::ReadAllText($vars)
  if ($ten) { $txt = [regex]::Replace($txt, '(?m)^Ten=[^\r\n]*', 'Ten=' + $ten.Trim()) }
  $txt = [regex]::Replace($txt, '(?m)^Scale=[^\r\n]*', 'Scale=' + ($sc -replace ',', '.'))
  [IO.File]::WriteAllText($vars, $txt, [Text.Encoding]::Unicode)
  if (Send-Bang @('!RefreshApp')) { Ok 'Đã cập nhật lời chào và kích cỡ.' }
}

# ---------------------------------------------------------------- 6. Wallpaper Engine
function Open-WallpaperEngine {
  Title '6. WALLPAPER ENGINE'
  $steam = $null
  try { $steam = (Get-ItemProperty 'HKCU:\Software\Valve\Steam' -ErrorAction Stop).SteamPath } catch {}
  if (-not $steam) { Warn 'Chưa có Steam → mở trang tải Steam.'; Start-Process 'https://store.steampowered.com/about/'; return }
  Ok ('Steam: ' + $steam)
  $libs = @($steam)
  $vdf = Join-Path $steam 'steamapps\libraryfolders.vdf'
  if (Test-Path $vdf) { Select-String -Path $vdf -Pattern '"path"\s+"(.+)"' | ForEach-Object { $libs += ($_.Matches[0].Groups[1].Value -replace '\\\\', '\') } }
  $we = $libs | ForEach-Object { Join-Path $_ 'steamapps\common\wallpaper_engine' } | Where-Object { Test-Path $_ } | Select-Object -First 1
  if ($we) { Ok ('Đã có Wallpaper Engine: ' + $we) } else { Warn 'Chưa có Wallpaper Engine → mở trang Steam của app.'; Start-Process ('steam://store/' + $WE_APPID) }
  $a = Read-Host 'Mở bộ sưu tập Workshop của shop để Subscribe? (y/n)'
  if ($a -eq 'y') { Start-Process ('steam://openurl/' + $WORKSHOP) }
  Write-Host ''
  Info 'Checklist cài đặt trong Wallpaper Engine (Settings > Performance):'
  Info '  • Other application focused: Keep running   • Other application maximized: Pause'
  Info '  • Other application fullscreen: Stop (free memory)   • Laptop on battery: Pause'
  Info '  • FPS / Quality theo đề xuất ở mục 1   • General > Start with Windows: bật (High priority)'
}

# ---------------------------------------------------------------- menu
function Show-Menu {
  Clear-Host
  Write-Host '  desktopchill · Setup Kit' -ForegroundColor Red
  Write-Host '  ------------------------------------------------'
  Write-Host '  1  Kiểm tra máy + đề xuất cài đặt (copy tóm tắt)'
  Write-Host '  2  Cài Rainmeter (im lặng)'
  Write-Host '  3  Cài bộ skin của shop (.rmskin trong thư mục files)'
  Write-Host '  4  Áp layout chuẩn'
  Write-Host '  5  Lưu layout hiện tại thành layout chuẩn  (dùng trên máy bạn)'
  Write-Host '  6  Wallpaper Engine: kiểm tra + mở Workshop + checklist'
  Write-Host '  7  Cá nhân hoá skin desktopchill (tên khách + kích cỡ)'
  Write-Host '  A  Chạy 1 → 2 → 3 → 4 → 7 → 6 liên tục'
  Write-Host '  Q  Thoát'
  Write-Host ''
}
function Safe([scriptblock]$b) { try { & $b } catch { Warn ('Lỗi: ' + $_.Exception.Message) } }

if ($args.Count -gt 0 -and $args[0] -eq '--check-only') { Safe { Check-Machine }; return }
while ($true) {
  Show-Menu
  $c = (Read-Host 'Chọn').Trim().ToUpper()
  switch ($c) {
    '1' { Safe { Check-Machine }; Pause-Enter }
    '2' { Safe { Install-Rainmeter }; Pause-Enter }
    '3' { Safe { Install-Skins }; Pause-Enter }
    '4' { Safe { Apply-Layout }; Pause-Enter }
    '5' { Safe { Save-Layout }; Pause-Enter }
    '6' { Safe { Open-WallpaperEngine }; Pause-Enter }
    '7' { Safe { Personalize-DcSkin }; Pause-Enter }
    'A' { Safe { Check-Machine }; Safe { Install-Rainmeter }; Safe { Install-Skins }; Safe { Apply-Layout }; Safe { Personalize-DcSkin }; Safe { Open-WallpaperEngine }; Pause-Enter }
    'Q' { return }
    default { }
  }
}
