@echo off
chcp 65001 >nul
title desktopchill Setup Kit
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup.ps1" %*
